#!/bin/bash
pwd
whoami
