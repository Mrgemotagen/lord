#!/bin/bash
echo "The current directory is:"
pwd
echo "The user logged in is :"
whoami