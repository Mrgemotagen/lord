#!/bin/bash
echo "Home for the current user is: $HOME"
