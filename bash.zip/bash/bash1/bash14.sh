#!/bin/bash
echo "I have \$1 in my pocket"