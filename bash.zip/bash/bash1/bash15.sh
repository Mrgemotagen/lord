#!/bin/bash
grade=5
person="Adam"
echo '$person    is a good boy, he is in grade $grade'
