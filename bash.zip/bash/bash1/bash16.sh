#!/bin/bash
mydir=$(pwd)
echo $mydir
