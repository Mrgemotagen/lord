#!/bin/bash
var1=$((5+5))
echo $var1
var2=$(($var1*2))
echo $var2