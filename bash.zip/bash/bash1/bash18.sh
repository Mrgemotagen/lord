#!bin/bash
if pwd 
then 
echo "It works"
fi


user="emin"
if grep $user /etc/passwd
then 
echo "The user $user Exists"
else 
echo "The user $user doesn't exist"
fi


val1="text"
val2="another text"
if [ $val1 \> "$val2" ]
then 
echo "$val1 is greater than $val2"
else
echo "$val1 is less than $val2"
fi
 

mydir=Загрузки
if [ -d $mydir ]
then
echo "The $mydir directory exists"
cd $mydir
ls
else
echo "The $mydir directory does not exist"
fi
