#!/bin/bash
for var in first second third fourth fifth
do 
echo "The $var item"
done


for var in first "the second" "the third" "I'll do it"
do
echo "This is: $var"
done
