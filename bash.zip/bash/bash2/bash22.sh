#!/bin/bash
file="myfile.txt"
for var in $(cat $file)
do
echo " $var"
done

file="/etc/passwd"
IFS=$'\n'
for var in $(cat $file)
do
echo ' $var'
done
