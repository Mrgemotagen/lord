#!/bin/bash
echo -n "Enter your name: "
read name
echo "Hello $name, welcome to my program"

