#!/bin/bash
read -p "Enter your name: " first last
echo "Your data for $last, $first"

