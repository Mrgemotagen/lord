#!/bin/bash
read -p "Enter your name: "
echo Hello $REPLY, welcome to my program

