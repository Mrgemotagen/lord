#!/bin/bash
echo Hello $1, how do you do

