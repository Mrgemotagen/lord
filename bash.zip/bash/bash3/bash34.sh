#!/bin/bash
echo There were $# parameters passed.
