#!/bin/bash
echo "Using the \$* method: $*"
echo "----------------"
echo "Using the \$@ method: $@"

