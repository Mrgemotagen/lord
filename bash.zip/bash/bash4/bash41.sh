#!/bin/bash
echo "This is an error" >&2
echo "This is normal output"
